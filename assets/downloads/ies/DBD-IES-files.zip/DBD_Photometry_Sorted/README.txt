DBD Denver iD Bollard - sorted photometry
112 IES files sorted by CCT / DO-SU / AY-NR / LS-Standard.
Whole-number wattages in file names (e.g. 9W).
Photometric data remains byte-for-byte unchanged.
Manufacturer LED codes retained.
BIM/dbd.rfa included. Original nested BIM zip omitted as redundant.
LS, DO, SU, AY and NR nomenclature is preserved from the supplied manufacturer files.
No photometric compliance assessment performed.
