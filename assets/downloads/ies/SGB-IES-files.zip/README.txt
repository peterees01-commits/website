SGB / Signature Bollard photometry - sorted by manufacturer-declared distribution, CCT, and measured photometry variant.

AY = asymmetric; SY = symmetric. The manufacturer catalogue does not explicitly establish these as single-open versus double-open configurations.

V1-V4 are NOT manufacturer optic names. These labels retain distinct manufacturer-measured photometry that happens to differ by source finish code.
V1 = source C1; V2 = source C4; V3 = source C6/C9; V4 = source C7.

Manufacturer source data is preserved byte-for-byte. Filename wattages are whole numbers; raw numeric IES content is unchanged.
For a finish-independent lighting-design reference, request from Holophane which dataset represents the correct intended product or whether finish-specific files are mandatory.

BIM ZIP in original package contained no useful family.
