FACTOR SMALL PHOTOMETRY

Files have been reorganised by colour temperature and optic.
Original IES filenames and file contents have not been altered.

Folder structure:
3000K / AY, FW, NR, SY
4000K / AY, FW, NR, SY

The Photometry Index.csv provides a complete file listing.
