FACTOR SMALL PHOTOMETRY

74 IES files arranged by colour temperature and optic.
File names have the measured/rated input wattage from the IES LM-63 photometric data appended as .<wattage>W before .ies.
The IES file contents are unchanged.

Folders: 3000K / AY, FW, NR, SY and 4000K / AY, FW, NR, SY.
Photometry Index.csv lists original and updated file names and wattages.
