SIG PHOTOMETRY — SORTED INDEX

180 original IES files, unmodified byte-for-byte.
Folder order: Colour Temperature > Optic > Mount > Backlight shield.
Names retain the exact original model code and append IES input wattage (rounded to nearest whole watt).
SE = Arm Mount; VB1 = Post Top (as specified in IES luminaire descriptions).
AY = Asymmetric; NR = Long & Narrow; SY = Symmetric (as indicated in IES descriptors).
BLS = Backlight Shield. No_BLS = standard/unshielded file.
Wattage is taken from the LM-63 numeric lamp/ballast/photometric watts line, not a nominal marketed rating.
IES_File_Index.csv includes exact unrounded wattages and luminaire flux.
Non-IES files and empty source folders excluded.
